# Model Deployment (To be updated)

MMRotate 1.x fully relies on [MMDeploy](https://mmdeploy.readthedocs.io/) to deploy models.
Please stay tuned and this document will be update soon.

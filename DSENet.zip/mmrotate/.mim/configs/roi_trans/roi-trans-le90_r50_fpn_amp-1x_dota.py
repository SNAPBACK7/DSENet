_base_ = './roi-trans-le90_r50_fpn_1x_dota.py'

optim_wrapper = dict(type='AmpOptimWrapper')

# Copyright (c) OpenMMLab. All rights reserved.

__version__ = '1.0.0rc1'
short_version = __version__

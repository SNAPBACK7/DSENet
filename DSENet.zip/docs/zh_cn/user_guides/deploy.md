# 模型部署 (待更新)

MMRotate 1.x 完全基于 [MMDeploy](https://mmdeploy.readthedocs.io/) 來部署模型。 我们将在下一个版本完善这个文档。
